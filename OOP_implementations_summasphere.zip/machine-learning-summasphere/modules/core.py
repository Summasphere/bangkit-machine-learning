############## IMPORT NECESSARY LIBRARIES ###############

import os
import nltk
nltk.download('punkt')
nltk.download('stopwords')
nltk.download('wordnet')
from nltk.corpus import stopwords
from nltk.corpus import wordnet
from nltk.stem import WordNetLemmatizer

import PyPDF2
import re

import string
from collections import Counter
import google.generativeai as genai

import keras_nlp
import tensorflow as tf
import yaml

import matplotlib.pyplot as plt
from wordcloud import WordCloud
from io import BytesIO
import base64
import random
from modules.util import sanitize_text, string_to_object, process_url

################## DEFINE THE ENV VARIABLES #####################
os.environ["KERAS_BACKEND"] = "tensorflow"
os.environ["HF_TOKEN"] = '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'
os.environ["NGROK_AUTH_TOKEN"] = "2G2icyyKNkA1kieM5ozGQE2OoPc_2zzQUhDgmSxiadgTQ2XDD"


################## LOAD CONFIGURATIONS #####################
with open("./config.yaml", "r") as file:
    config = yaml.safe_load(file)

url = "https://huggingface.co/mnabielap/bart-multinews/resolve/main/bart-multinews.keras"
local_path = "bart-multinews.keras"
# os.system(f"wget {url} -O {local_path}")

############## DEFINE GLOBAL POINTER FOR API ##############
POINTER = 0
GEMINI_API_KEY_COLLECTION = config["GEMINI_API_KEY_COLLECTION"]
random.shuffle(GEMINI_API_KEY_COLLECTION)

################### SUMMARIZER CLASS ############################
class BartSummarizer: # /summarize/bart
    def __init__(self, max_length = 256):
        self.max_length = max_length
        self.bart_model = tf.keras.models.load_model(
            local_path,
            custom_objects={"BartSeq2SeqLM": keras_nlp.models.BartSeq2SeqLM}
        )

    def summarize(self, input_text):
        output = self.bart_model.generate(input_text, max_length=self.max_length)
        return output

class GeminiLLM():
    def __init__(self, configs=config):
        self.maximum_try = 10
        self.api_key = GEMINI_API_KEY_COLLECTION
        self.generation_conf = configs["generation_config"]
        self.safety_settings = [
            {
                "category": "HARM_CATEGORY_HARASSMENT",
                "threshold": "BLOCK_LOW_AND_ABOVE",
            },
            {
                "category": "HARM_CATEGORY_HATE_SPEECH",
                "threshold": "BLOCK_LOW_AND_ABOVE",
            },
            {
                "category": "HARM_CATEGORY_SEXUALLY_EXPLICIT",
                "threshold": "BLOCK_LOW_AND_ABOVE",
            },
            {
                "category": "HARM_CATEGORY_DANGEROUS_CONTENT",
                "threshold": "BLOCK_LOW_AND_ABOVE",
            },
        ]

    def pick_random_key(self):
        global POINTER
        if self.api_key:
            pair_api_key = self.api_key[POINTER]
            POINTER = (POINTER + 1) % len(self.api_key) # move to the next
            api_key, email_name = pair_api_key
            print(f"Using API Key from -> {email_name}")
            return api_key
        else:
            return "No more API keys available."

    def generate_result(self, input_text, system_instruction):
        input_text = sanitize_text(input_text)
        api_key = self.pick_random_key()
        genai.configure(api_key=api_key)

        model = genai.GenerativeModel(
            model_name="gemini-1.5-flash",
            safety_settings=self.safety_settings,
            generation_config=self.generation_conf,
            system_instruction=system_instruction,
        )

        chat_session = model.start_chat(history=[])
        response = chat_session.send_message(input_text)

        response_text = response.text
        return response_text

    ######## UTILITY FUNCTION ########
    def extract_text_from_pdf(self, pdf_path):
        pdf_reader = PyPDF2.PdfReader(pdf_path)
        text = ""
        for page_num in range(len(pdf_reader.pages)):
            page = pdf_reader.pages[page_num]
            text += page.extract_text()
        return text

    def create_str_json_example(self, num_topic: int):
        res = "[\n"
        for no_topic in range(num_topic):
            no_topic += 1
            comma = ',' if no_topic != num_topic else ''
            temp = '''
            {
                "topic":"{name_topic_'''.strip() + str(no_topic) + '''}",
                "percentage":{percentage_'''.strip() + str(no_topic) + '''},
                "detail":"{explanation_'''.strip() + str(no_topic) + '''}"
            }
            '''.strip() + str(comma)
            res += f"  {temp}\n"
        res += "]"
        return res
    ##################################

class GeminiSummarizer(GeminiLLM): # /summarize/gemini
    def __init__(self, configs=config):
        super().__init__(configs)

    def process_text(self, input_text):
        system_instruction='Objective:\nYou are summarization application specifically designed for researchers to efficiently extract key information from academic papers. Researchers often face the challenge of sifting through numerous papers to find inspiration and relevant information, but only about 20% of a paper typically contains the critical insights they need. This application aims to expedite the literature review process by providing concise, targeted summaries focusing on the most valuable parts of each paper.\n\nKey Requirements:\n\nMethodology Summary: Clearly outline the research methods used, including experimental design, data collection, and analysis techniques.\n\nEquations: Highlight and extract every important equation if exists. The equations must be written in LaTeX so it can be rendered in markdown media. Do not let more than three equations on the same line, if there are more than three, put it in the new line. Make sure to always use the equation environment to write an equation that is given in a line, e.g. $$ H_ {k_p}=frac {Y_ {k_p}} {X_ {k_p}} $$. Also, make sure to be careful on writing equations from documents provided by user, because sometimes PDF breaks the latex format and you might write it wrong. Make sure to not forget every detail, for example you must write it like\n\n$$ A_{dot} = \\text{softmax} (  \n\\frac {QK^T} {\\sqrt{d_{model}}}  \n) V. $$  \n$$ A_{mem} = \\frac{σ(Q)M_{s-1}}\n{σ(Q)z_{s−1}} . $$  \n$$ M_{s} ← M_{s−1} + σ(K)^TV \\text{ and } z_{s} ← z_{s−1} + \\sum_{t=1}^{N} \nσ(K_{t}). $$  \n$$ M_{s} ← M_{s−1} + σ(K)^T(V − \\frac{σ(K)M_{s−1}}{σ(K)z_{s−1}}). $$\n\nMake sure to do deeper reasoning to implement the equation correctly, I know you render the equations from PDF directly, but use your knowledge to figure out how is it supposed to be written correctly. Do not just write what you saw directly.\n\nResults Summary: Highlight the main findings and outcomes of the research, emphasizing significant results and conclusions.\nCitations for Each Argument: Provide citations AND paper reference in APA style in the end of the summary, for key arguments and claims made within the paper to facilitate further reading and verification. The citation must be written in APA style, extract from the Reference Section in the input document if exists. REMEMBER, just provide the some needed citations and reference only, no need to provide all of the citations used on the paper.\n\nImportant Aspects of the Method: Identify and summarize critical aspects and innovations of the methodology that contribute to the research field.\n\nApplication Expectations:\n\nNon-Generic Summaries: The application should avoid general summaries (such as abstracts) and focus on specific sections that contain essential details for researchers.\nEfficiency and Accuracy: Ensure that the summarization process is fast and accurate, enabling researchers to quickly grasp the core contributions of each paper.\nUser-Centric Design: Tailor the application interface and features to meet the needs of researchers, allowing them to customize the type and depth of summaries they receive.\nOutcome:\nBy using you, researchers should be able to significantly reduce the time spent on literature reviews, thereby enhancing their productivity and enabling them to produce more research papers. The application should act as a valuable tool in accelerating the research process and improving the overall quality of academic work.\n\nYou are not allowed to answer another question aside summarization task. Expected responses:\n\nExample 1:\nUsers: "Hello"\nYou: <No response>\n\nExample 2:\nUsers: "Umm"\nYou: <No response>\n'
        response_text = self.generate_result(input_text, system_instruction)
        return response_text

    def run_gemini_summarizer(self, text, mode="text"):
        if mode == "pdf":
            text = self.extract_text_from_pdf(text)

        for _ in range(self.maximum_try):
            try:
                summary = self.process_text(text)
                return summary
            except Exception as e:
                print(f"error: {e}")
        return "Failed to summarize the text. Please try again later."

################### ANALYZER CLASS ############################
class TopicModelling(GeminiLLM):
    def __init__(self, configs=config):
        super().__init__(configs)

    def process_text(self, input_text):
        system_instruction=f"""
            Analyze the 5 most related topics in the text below. explain each topic completely. explain why the text fits the topic.
            >> Constraint:
            - minimum 100 words and maximum 500 words
            - also explain how many percent of each topic is related to the text.
            - provide in a formal, no-nonsense format so that these results can be used for academic purposes.
            - to the point
            - the output must be json format for example
            {self.create_str_json_example(5)}
            - do not provide any text outside of json
            """.strip()
        response_text = self.generate_result(input_text, system_instruction)
        return response_text

    def wordcloud(self, text):
        text = str(text).lower()
        text = re.sub(r'\d+', '', text)
        text = text.translate(str.maketrans('', '', string.punctuation))
        words = text.split()
        words = [word for word in words if len(word) > 2]

        additional_stopwords = {'could', 'would', 'never', 'one', 'even', 'like', 'said', 'say', 'also',
                                'might', 'must', 'every', 'much', 'may', 'two', 'know', 'upon', 'without',
                                'go', 'went', 'got', 'put', 'see', 'seem', 'seemed', 'take', 'taken',
                                'make', 'made', 'come', 'came', 'look', 'looking', 'think', 'thinking',
                                'thought', 'use', 'used', 'find', 'found', 'give', 'given', 'tell', 'told',
                                'ask', 'asked', 'back', 'get', 'getting', 'keep', 'kept', 'let', 'lets',
                                'seems', 'leave', 'left', 'set', 'from', 'subject', 're', 'edu', 'use'}
        custom_stopwords = set(stopwords.words('english')).union(additional_stopwords)

        filtered_words = [word for word in words if word not in custom_stopwords]

        lemmatizer = WordNetLemmatizer()
        lemmatized_words = [lemmatizer.lemmatize(word) for word in filtered_words]
        word_freq = Counter(lemmatized_words)
        sorted_word_freq = sorted(word_freq.items(), key=lambda item: item[1], reverse=True)
        temp_dict = dict()
        for key, val in sorted_word_freq:
            temp_dict[key] = val
        return temp_dict

    ######################## ANDROID UTILITY ########################
    def barplot_to_base64(self, data):
        # Extracting data for plotting
        topics = [item['topic'] for item in data]
        percentages = [item['percentage'] for item in data]

        # Creating the barplot
        plt.figure(figsize=(10, 6))
        plt.barh(topics, percentages, color='skyblue')
        plt.xlabel('Percentage')
        plt.ylabel('Topic')
        plt.title('Distribution of Topics in Quantum Computing')
        plt.gca().invert_yaxis()  # Invert y-axis to have the highest percentage on top

        # Save the plot to a BytesIO object
        buf = BytesIO()
        plt.savefig(buf, format='png')
        buf.seek(0)

        # Encode the BytesIO object to base64
        img_base64 = base64.b64encode(buf.read()).decode('utf-8')
        buf.close()

        return img_base64

    def wordcloud_to_base64(self, word_freq):
        wordcloud = WordCloud(width=800, height=400, background_color='white').generate_from_frequencies(word_freq)
        plt.figure(figsize=(10, 5))
        plt.imshow(wordcloud, interpolation='bilinear')
        plt.axis('off')

        buffer = BytesIO()
        plt.savefig(buffer, format='png')
        plt.close()
        buffer.seek(0)
        img_str = base64.b64encode(buffer.read()).decode('utf-8')
        return img_str
    ########################################################################

    def run_analysis(self, text, mode="pdf", media="frontend"):
        if mode == "pdf":
            text = self.extract_text_from_pdf(text)
        elif mode == "link":
            text = process_url(text)

        for _ in range(self.maximum_try):
            try:
                topic_dist = self.process_text(text)
                break
            except Exception as e:
                print(f"error: {e}")
        try:
            topic_dist = string_to_object(topic_dist[topic_dist.index("["):topic_dist.rindex("]")+1])
        except Exception:
            topic_dist = string_to_object(topic_dist[topic_dist.index("{"):topic_dist.rindex("}")+1])

        wordcloud_dict = self.wordcloud(text)

        if mode == "android":
            topic_dist_img = self.barplot_to_base64(topic_dist)
            wordcloud_img = self.wordcloud_to_base64(wordcloud_dict)
            dict_analysis = {"topic_distribution": topic_dist_img, "wordcloud": wordcloud_img}
        else:
            dict_analysis = {"topic_distribution": topic_dist, "wordcloud": wordcloud_dict}

        return dict_analysis